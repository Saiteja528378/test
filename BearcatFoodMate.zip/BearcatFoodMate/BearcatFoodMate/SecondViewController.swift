//
//  SecondViewController.swift
//  Bearcat FM
//
//  Created by Lohita Reddy Vanga on 2/10/17.
//  Copyright © 2017 Lohita Reddy Vanga. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

